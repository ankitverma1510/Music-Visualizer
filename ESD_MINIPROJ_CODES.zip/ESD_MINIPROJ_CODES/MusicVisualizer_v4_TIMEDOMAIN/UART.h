
#ifndef UART_H_
#define UART_H_


    int UART_Init(int);

    int UART_Write(int , unsigned char *);

    int UART_Read(int ,  unsigned char *);

    //int UART_BytesInRx();

#endif /* UART_H_ */
