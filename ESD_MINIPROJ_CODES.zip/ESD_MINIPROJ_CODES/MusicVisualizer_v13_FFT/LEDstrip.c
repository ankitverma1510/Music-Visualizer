#include <stdint.h>
#include <stdbool.h>
#include <./inc/tm4c123gh6pm.h>
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <driverlib/gpio.h>
#include <driverlib/pin_map.h>
#include <driverlib/sysctl.h>
#include <string.h>

#include "LEDstrip.h"


void Write_Level(int lvl)
{
    switch(lvl)
        {
        case 0:
            Write_B();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();


    break;
        case 1:
            Write_B();
            Write_B();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 2:
            Write_B();
            Write_B();
            Write_GB();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 3:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 4:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 5:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 6:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 7:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_off();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 8:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_RG();
            Write_off();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 9:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_RG();
            Write_RG();
            Write_off();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 10:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_RG();
            Write_RG();
            Write_RG();
            Write_off();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;
        case 11:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_RG();
            Write_RG();
            Write_RG();
            Write_RG();

            Write_off();
            Write_off();
            Write_off();
            Write_off();
    break;

        case 12:
            Write_B();
            Write_B();
            Write_GB();
            Write_GB();

            Write_GB();
            Write_G();
            Write_G();
            Write_G();

            Write_RG();
            Write_RG();
            Write_RG();
            Write_RG();

            Write_R();
            Write_off();
            Write_off();
            Write_off();
    break;

        case 13:
             Write_B();
             Write_B();
             Write_GB();
             Write_GB();

             Write_GB();
             Write_G();
             Write_G();
             Write_G();

             Write_RG();
             Write_RG();
             Write_RG();
             Write_RG();

             Write_R();
             Write_R();
             Write_off();
             Write_off();
     break;

        case 14:
             Write_B();
             Write_B();
             Write_GB();
             Write_GB();

             Write_GB();
             Write_G();
             Write_G();
             Write_G();

             Write_RG();
             Write_RG();
             Write_RG();
             Write_RG();

             Write_R();
             Write_R();
             Write_R();
             Write_off();
     break;


        case 15:
             Write_B();
             Write_B();
             Write_GB();
             Write_GB();

             Write_GB();
             Write_G();
             Write_G();
             Write_G();

             Write_RG();
             Write_RG();
             Write_RG();
             Write_RG();

             Write_R();
             Write_R();
             Write_R();
             Write_R();
     break;

        }


}



void screenUpdate(volatile int8_t* ScreenLevels)
{
    Write_Level(ScreenLevels[0]);
    Write_Level(ScreenLevels[1]);
    Write_Level(ScreenLevels[2]);
    Write_Level(ScreenLevels[3]);

    Write_Level(ScreenLevels[4]);
    Write_Level(ScreenLevels[5]);
    Write_Level(ScreenLevels[6]);
    Write_Level(ScreenLevels[7]);
}


void LEDstripInit()
{
    SYSCTL_RCGC2_R |= 0x00000020;     /* enable clock to GPIOF at clock gating control register */

       GPIO_PORTF_DIR_R = 0x02;          /* enable the GPIO pins for the LED (PF3, 2, 1) as output */
       GPIO_PORTF_DEN_R = 0x02;         /* enable the GPIO pins for digital function */
}






