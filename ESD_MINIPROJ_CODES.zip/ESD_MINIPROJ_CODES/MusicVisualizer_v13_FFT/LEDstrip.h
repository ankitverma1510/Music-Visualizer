#ifndef LEDSTRIP_H_
#define LEDSTRIP_H_


#define Write_0() {\
    GPIO_PORTF_DATA_R= 0x02;\
    __asm  ("    NOP  \n");\
    __asm  ("    NOP  \n");\
    GPIO_PORTF_DATA_R= 0x00;\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
     __asm  ("    NOP  \n");\
}

#define Write_1() {\
        GPIO_PORTF_DATA_R= 0x02;\
            __asm  ("    NOP  \n");\
            __asm  ("    NOP  \n");\
            __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
                         __asm  ("    NOP  \n");\
            GPIO_PORTF_DATA_R= 0x00;\
             __asm  ("    NOP  \n");\
             __asm  ("    NOP  \n");\
             __asm  ("    NOP  \n");\
}




#define Write_R() {\
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
\
            Write_0();\
                Write_0();\
                Write_0();\
                Write_1();\
                Write_1();\
                Write_1();\
                Write_1();\
                Write_1();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
\
}

#define Write_RG() {\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_1();\
       Write_1();\
       Write_1();\
       \
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_1();\
            Write_1();\
            Write_1();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
\
}

#define Write_G() {\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_1();\
       Write_1();\
       Write_1();\
       Write_1();\
       Write_1();\
       \
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
\
}


#define Write_GB() {\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_1();\
       Write_1();\
       Write_1();\
       \
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_1();\
                   Write_1();\
                   Write_1();\
\
}





#define Write_B() {\
       \
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_1();\
            Write_1();\
            Write_1();\
            Write_1();\
            Write_1();\
}


#define Write_off() {\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       Write_0();\
       \
        Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
            Write_0();\
\
                Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
                   Write_0();\
\
}


void Write_Level(int );


void screenUpdate(volatile int8_t* );


void LEDstripInit();









#endif /* LEDSTRIP_H_ */
