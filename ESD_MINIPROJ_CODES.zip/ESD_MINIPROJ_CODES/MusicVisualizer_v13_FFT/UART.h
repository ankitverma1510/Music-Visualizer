
#ifndef UART_H_
#define UART_H_

#include <complex.h>
    void UART_debug(int );

    int UART_Init(int);

    int UART_Write(int , unsigned char *);

    int UART_Read(int ,  unsigned char *);
    void UART_newline();

    void UART_showComplex(complex float);

#endif /* UART_H_ */
