#ifndef DELAY_H_
#define DELAY_H_

 void delayMs(int );
 void delayUs(int );



#endif /* DELAY_H_ */
